# Pharmacy MANAGEMENT SYSTEM - 2019


DBMS PROJECT - Using PHP, MySQL, HTML, CSS


Server-XAMPP


Multi User Login System- Customer , Pharmacist, Admin.

Download the repository

Save it under htdocs folder in XAMPP 

Start XAMPP server 

Create Database in PHPMyAdmin 

Go to localhost/foldername

------------THE END-----------------------
